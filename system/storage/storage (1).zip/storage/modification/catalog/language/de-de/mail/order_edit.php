<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Bestell-Update %s';
$_['text_order_id']     = 'Auftragsnummer:';
$_['text_date_added']   = 'Datum hinzugefügt:';
$_['text_order_status'] = 'Ihre Bestellung wurde auf den folgenden Status aktualisiert:';
$_['text_comment']      = 'Die Kommentare für Ihre Bestellung sind:';
$_['text_link']         = 'Um Ihre Bestellung anzusehen, klicken Sie auf den folgenden Link:';
$_['text_footer']       = 'Bitte antworten Sie auf diese E-Mail, wenn Sie Fragen haben.';