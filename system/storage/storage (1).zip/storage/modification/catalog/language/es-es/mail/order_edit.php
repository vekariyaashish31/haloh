<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Solicitar actualización %s';
$_['text_order_id']     = 'Solicitar ID:';
$_['text_date_added']   = 'Fecha Agregada:';
$_['text_order_status'] = 'Su orden ha sido actualizada al siguiente estado:';
$_['text_comment']      = 'Los comentarios para su pedido son:';
$_['text_link']         = 'Para ver su pedido, haga clic en el siguiente enlace:';
$_['text_footer']       = 'Responda a este correo electrónico si tiene alguna pregunta.';