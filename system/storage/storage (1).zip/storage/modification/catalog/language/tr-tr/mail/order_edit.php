<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']       = '%s - %s Nolu Siparişinizin Durumu Güncellendi';
$_['text_order_id']      = 'Sipariş No:';
$_['text_date_added']    = 'Sipariş Tarihi:';
$_['text_order_status']  = 'Siparişiniz aşağıdaki duruma güncellendi:';
$_['text_comment']       = 'Siparişiniz ile ilgili açıklamalar:';
$_['text_link']          = 'Siparişinizi görüntülemek için aşağıdaki bağlatıya tıklayınız:';
$_['text_footer']        = 'Herhangi bir sorunuz varsa bu e-postayı yanıtlayınız.';