<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Aggiornamento ordine %s';
$_['text_order_id']     = 'ID ordine:';
$_['text_date_added']   = 'Data aggiunta:';
$_['text_order_status'] = 'Il tuo ordine è stato aggiornato al seguente stato:';
$_['text_comment']      = 'I commenti per il tuo ordine sono:';
$_['text_link']         = 'Per visualizzare il tuo ordine clicca sul link sottostante:';
$_['text_footer']       = 'Si prega di rispondere a questa e-mail se avete domande.';