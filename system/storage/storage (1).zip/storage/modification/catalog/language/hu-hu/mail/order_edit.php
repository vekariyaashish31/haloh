<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Megrendelés frissítése %s';
$_['text_order_id']     = 'Rendelés azonosító:';
$_['text_date_added']   = 'Dátum hozzáadva:';
$_['text_order_status'] = 'Megrendelését a következő állapotra frissítették:';
$_['text_comment']      = 'A megrendelésre vonatkozó megjegyzések a következők:';
$_['text_link']         = 'A megrendelés megtekintéséhez kattints az alábbi linkre:';
$_['text_footer']       = 'Ha bármilyen kérdése van, válaszoljon erre az e-mailre.';