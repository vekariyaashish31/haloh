<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - อัพเดทคำสั่งซื้อ %s';
$_['text_order_id']     = 'คำสั่งซื้อ หมายเลข:';
$_['text_date_added']   = 'วันที่:';
$_['text_order_status'] = 'ใบสั่งซื้อของคุณได้รับการอัปเดตเป็นสถานะต่อไปนี้:';
$_['text_comment']      = 'ความคิดเห็นสำหรับการสั่งซื้อของคุณคือ:';
$_['text_link']         = 'คลิกที่ลิงค์ด้านล่างเพื่อดูคำสั่งซื้อของคุณ:';
$_['text_footer']       = 'โปรดตอบกลับอีเมลนี้หากคุณมีคำถามใดๆ';



/*
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Order Update %s';
$_['text_order_id']     = 'Order ID:';
$_['text_date_added']   = 'Date Added:';
$_['text_order_status'] = 'Your order has been updated to the following status:';
$_['text_comment']      = 'The comments for your order are:';
$_['text_link']         = 'To view your order click on the link below:';
$_['text_footer']       = 'Please reply to this email if you have any questions.';
*/