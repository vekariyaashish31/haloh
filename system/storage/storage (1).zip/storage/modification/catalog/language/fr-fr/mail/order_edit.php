<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Mise à jour %s';
$_['text_order_id']     = 'Numéro de commande:';
$_['text_date_added']   = 'Date ajoutée:';
$_['text_order_status'] = 'Votre commande a été mise à jour pour le statut suivant:';
$_['text_comment']      = 'Les commentaires pour votre commande sont:';
$_['text_link']         = 'Pour voir votre commande, cliquez sur le lien ci-dessous:';
$_['text_footer']       = 'Veuillez répondre à cet e-mail si vous avez des questions.';