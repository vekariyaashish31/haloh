<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Aktualizace objednávky %s';
$_['text_order_id']     = 'Číslo objednávky:';
$_['text_date_added']   = 'Datum přidáno:';
$_['text_order_status'] = 'Vaše objednávka byla aktualizována na následující stav:';
$_['text_comment']      = 'Komentáře k objednávce jsou:';
$_['text_link']         = 'Chcete-li zobrazit svou objednávku, klikněte na následující odkaz:';
$_['text_footer']       = 'Pokud máte nějaké dotazy, odpovězte na tento e-mail.';