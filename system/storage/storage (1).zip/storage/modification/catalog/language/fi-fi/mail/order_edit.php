<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Tilauspäivitys %s';
$_['text_order_id']     = 'Tilausnumero:';
$_['text_date_added']   = 'Lisäyspäivämäärä:';
$_['text_order_status'] = 'Tilauksesi on päivitetty seuraavaan tilaan:';
$_['text_comment']      = 'Tilauksesi kommentit ovat:';
$_['text_link']         = 'Voit tarkastella tilaustasi klikkaamalla alla olevaa linkkiä:';
$_['text_footer']       = 'Vastaa tähän sähköpostiviestiin, jos sinulla on kysyttävää.';