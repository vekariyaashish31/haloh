<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - עדכון הזמנה %s';
$_['text_order_id']     = 'מספר זיהוי הזמנה:';
$_['text_date_added']   = 'נוסף בתאריך:';
$_['text_order_status'] = 'הזמנתך עודכנה לסטטוס :';
$_['text_comment']      = 'ההערות עבור ההזמנה שלך הן:';
$_['text_link']         = 'על מנת לצפות בהזמנתך יש ללחוץ על הקישור שמתחת :';
$_['text_footer']       = 'נא להשיב לדואר אלקטרוני זה במידה ויש לך שאלה .';