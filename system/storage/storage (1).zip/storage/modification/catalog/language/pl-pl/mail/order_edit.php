<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - zaktualizuj zamówienie %s';
$_['text_order_id']     = 'ID zamówienia:';
$_['text_date_added']   = 'Data dodania:';
$_['text_order_status'] = 'Twoje zamówienie zostało zaktualizowane do następującego stanu:';
$_['text_comment']      = 'Komentarze do twojego zamówienia to:';
$_['text_link']         = 'Aby zobaczyć zamówienie, kliknij poniższy link:';
$_['text_footer']       = 'Jeśli masz jakiekolwiek pytania, odpowiedz na tego e-maila.';