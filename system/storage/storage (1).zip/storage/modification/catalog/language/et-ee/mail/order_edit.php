<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '% - Telli värskendust %';
$_['text_order_id']     = 'Tellimuse ID:';
$_['text_date_added']   = 'Kuupäev lisatud:';
$_['text_order_status'] = 'Teie tellimust on uuendatud järgmisele staatusele:';
$_['text_comment']      = 'Teie tellimuse kommentaarid on järgmised:';
$_['text_link']         = 'Tellimuse vaatamiseks klõpsake alloleval lingil:';
$_['text_footer']       = 'Kui teil on küsimusi, vastake sellele meilile.';