<?php
// Text
/*TMD*/
$_['text_new_image']            = 'Image';
/*TMD End*/
$_['text_subject']      = '%s - Beställ uppdatering %s';
$_['text_order_id']     = 'Order ID:';
$_['text_date_added']   = 'Datum tillagt:';
$_['text_order_status'] = 'Din order har uppdaterats till följande status:';
$_['text_comment']      = 'Kommentarer till din beställning är:';
$_['text_link']         = 'För att se din beställning, klicka på länken nedan:';
$_['text_footer']       = 'Vänligen svara på det här meddelandet om du har några frågor.';